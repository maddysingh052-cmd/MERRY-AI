package com.merry.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var conversation: TextView
    private lateinit var status: TextView
    private val requestAudioCode = 101
    private val requestSpeechCode = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudioCode)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "MERRY AI ❤️"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Hello Boss! Main MERRY hoon. Neeche mic dabakar baat karo."
            textSize = 17f
            setPadding(0, 24, 0, 20)
        }
        conversation = TextView(this).apply {
            text = "MERRY: Abhi main starter version hoon. AI brain connect karna agla step hai.\n"
            textSize = 16f
            setPadding(12, 12, 12, 12)
        }
        val scroll = ScrollView(this).apply {
            addView(conversation)
        }
        val micButton = Button(this).apply {
            text = "🎙️  MERRY se baat karo"
            textSize = 18f
            setOnClickListener { startListening() }
        }
        val speakButton = Button(this).apply {
            text = "MERRY ki voice test karo"
            setOnClickListener { speak("Hello Boss! Main MERRY hoon. Aapki AI assistant.") }
        }

        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(micButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(speakButton, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Is phone par speech recognition available nahi hai.", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudioCode)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Boss, MERRY ko boliye...")
        }
        try {
            startActivityForResult(intent, requestSpeechCode)
        } catch (_: Exception) {
            Toast.makeText(this, "Voice input start nahi ho paya.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Uses Activity result callback for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestSpeechCode && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                conversation.append("\n\nAap: $spoken\n")
                val reply = createStarterReply(spoken)
                conversation.append("MERRY: $reply\n")
                status.text = reply
                speak(reply)
            }
        }
    }

    private fun createStarterReply(input: String): String {
        val text = input.lowercase(Locale.ROOT)
        return when {
            "hello" in text || "hi" in text || "merry" in text ->
                "Hello Boss! Main MERRY hoon. Abhi mera basic version chal raha hai."
            "time" in text || "samay" in text || "baje" in text ->
                "Boss, exact time aapke phone ki status bar mein dikh raha hai. AI integration agle step mein add karenge."
            "youtube" in text -> {
                openApp("com.google.android.youtube")
                "Boss, YouTube kholne ki koshish kar rahi hoon."
            }
            "chrome" in text || "browser" in text -> {
                openApp("com.android.chrome")
                "Boss, browser kholne ki koshish kar rahi hoon."
            }
            else -> "Boss, maine suna: $input. Mujhe intelligent jawab dene ke liye agle step mein AI service connect karni hogi."
        }
    }

    private fun openApp(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "Yeh app phone mein nahi mili.", Toast.LENGTH_SHORT).show()
    }

    private fun speak(message: String) {
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "merry_utterance")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale.US
            }
            tts.setPitch(1.12f)
            tts.setSpeechRate(0.95f)
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}

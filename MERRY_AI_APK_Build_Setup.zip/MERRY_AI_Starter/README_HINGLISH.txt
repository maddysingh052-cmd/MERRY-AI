MERRY AI - Starter Android project
==================================

Starter features:
- Basic Android app screen
- Hindi speech input using Android speech recognition
- Voice response using Android Text-to-Speech
- Simple commands to try opening YouTube or Chrome

Not included yet:
- Real AI model/API connection
- Persistent memory
- Always-on "Hey Merry" wake word
- WhatsApp sending, calling, or advanced phone automation

BUILD AN APK USING GITHUB ACTIONS (PHONE-FRIENDLY APPROACH)
-----------------------------------------------------------
This ZIP includes .github/workflows/android.yml. It can build a debug APK online.

1. On your phone, sign in to https://github.com/ or create an account.
2. Create a NEW repository, for example: merry-ai-app. A public repository is easiest for following the steps; do not put secrets or personal data in it.
3. Extract this ZIP first if you have a way to upload folders. Upload the project files and folders into the repository, preserving their paths, including the hidden .github/workflows/android.yml file. GitHub's web uploader may not make hidden folders easy to upload from a phone.
4. Open the repository's Actions tab. If prompted, enable Actions.
5. If the workflow file is present, choose "Build MERRY AI APK" and tap "Run workflow" (or push to main to trigger it).
6. Wait for the workflow to finish successfully.
7. Open that workflow run, find Artifacts, and download "MERRY-AI-debug-APK".
8. Extract the artifact ZIP and install app-debug.apk on your phone. Android may ask permission to install unknown apps for the browser/file manager you use; only install APKs you built and trust.

Important:
- This is a debug/test APK, not a Play Store release.
- The workflow uses Android Gradle Plugin 8.7.3, Gradle 8.9 and Java 17.
- This environment cannot directly compile and test an APK because the Android SDK/build environment is not available here. GitHub Actions is the proposed remote build route.
- The GitHub upload process from a phone can be awkward because the project has nested folders and a hidden .github folder. If that becomes difficult, use a computer or another trusted repository upload method.
- Never hard-code an AI API key inside the Android app. For a real AI connection, use a secure backend or carefully controlled proxy.
